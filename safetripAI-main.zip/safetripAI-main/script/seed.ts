import { db } from "../server/db";
import { users, trips, tripPlaces, transportOptions, safetyInfo } from "../shared/db-schema";

async function seed() {
  console.log("Seeding database...");

  // Create sample user
  const [user] = await db.insert(users).values({
    name: "Demo User",
    email: "demo@safetrip.com",
    password: "demo123",
  }).returning();

  console.log("Created user:", user.email);

  // Create sample trip
  const [trip] = await db.insert(trips).values({
    userId: user.id,
    destination: "Chennai",
    startDate: new Date("2024-02-01"),
    endDate: new Date("2024-02-03"),
    status: "ACTIVE",
    currentLocation: "The Residency Towers, T Nagar",
    currentDay: 2,
    budget: "moderate",
  }).returning();

  console.log("Created trip:", trip.destination);

  // Create sample places
  const places = [
    {
      name: "Saravana Bhavan Breakfast",
      type: "restaurant",
      location: "T Nagar",
      time: "08:00 AM",
      distance: "1.2 km",
      day: 2,
      transport: [
        { type: "Rapido", price: 60, time: "5 min", recommended: true },
        { type: "Uber", price: 90, time: "7 min", recommended: false },
        { type: "Bus", price: 10, time: "15 min", recommended: false },
      ],
      safety: { hospital: "Apollo Hospital – 900m", police: "T Nagar Police Station – 700m" },
    },
    {
      name: "Marina Beach",
      type: "attraction",
      location: "Marina Beach Road",
      time: "10:30 AM",
      distance: "6 km",
      day: 2,
      transport: [
        { type: "Rapido", price: 120, time: "15 min", recommended: true },
        { type: "Uber", price: 180, time: "18 min", recommended: false },
        { type: "Bus", price: 20, time: "30 min", recommended: false },
      ],
      safety: { hospital: "Rajiv Gandhi Hospital – 1.5 km", police: "Marina Police Station – 500m" },
    },
    {
      name: "Murugan Idli Shop Lunch",
      type: "restaurant",
      location: "Besant Nagar",
      time: "01:30 PM",
      distance: "4 km",
      day: 2,
      transport: [
        { type: "Rapido", price: 100, time: "12 min", recommended: true },
        { type: "Uber", price: 150, time: "15 min", recommended: false },
        { type: "Bus", price: 15, time: "25 min", recommended: false },
      ],
      safety: { hospital: "Fortis Hospital – 2 km", police: "Besant Nagar Police Station – 1 km" },
    },
  ];

  for (let i = 0; i < places.length; i++) {
    const place = places[i];
    const [insertedPlace] = await db.insert(tripPlaces).values({
      tripId: trip.id,
      name: place.name,
      type: place.type,
      location: place.location,
      time: place.time,
      distance: place.distance,
      day: place.day,
      orderIndex: i,
    }).returning();

    await db.insert(transportOptions).values(
      place.transport.map(t => ({
        placeId: insertedPlace.id,
        type: t.type,
        price: t.price,
        time: t.time,
        recommended: t.recommended,
      }))
    );

    await db.insert(safetyInfo).values({
      placeId: insertedPlace.id,
      hospital: place.safety.hospital,
      police: place.safety.police,
    });

    console.log("Created place:", place.name);
  }

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
