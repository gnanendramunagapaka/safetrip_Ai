// Shared TypeScript types — no database dependency
// Previously used drizzle-orm/drizzle-zod; replaced with plain types.

export interface User {
  id: number;
  name: string;
  email: string;
  password: string;
  createdAt: Date;
}

export interface Trip {
  id: number;
  userId: number;
  destination: string;
  startDate: Date;
  endDate: Date;
  status: string;
  currentLocation?: string;
  currentDay: number;
  budget?: string;
  createdAt: Date;
}

export interface TripPlace {
  id: number;
  tripId: number;
  name: string;
  type: string;
  location: string;
  time: string;
  distance?: string;
  day: number;
  orderIndex: number;
  latitude?: number;
  longitude?: number;
}

export interface TransportOption {
  id: number;
  placeId: number;
  type: string;
  price: number;
  time: string;
  recommended: boolean;
}

export interface SafetyInfo {
  id: number;
  placeId: number;
  hospital: string;
  police: string;
}

export interface EmergencyContact {
  id: number;
  userId: number;
  name: string;
  phone: string;
}
