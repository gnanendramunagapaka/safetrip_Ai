import { z } from "zod";

export const transportSchema = z.object({
  type: z.string(),
  price: z.number(),
  time: z.string(),
  recommended: z.boolean().optional(),
});

export const safetySchema = z.object({
  hospital: z.string(),
  police: z.string(),
});

export const timelinePlaceSchema = z.object({
  id: z.string(),
  time: z.string(),
  name: z.string(),
  type: z.string(),
  distance: z.string(),
  location: z.string(),
  transport: z.array(transportSchema),
  safety: safetySchema,
});

export const tripInfoSchema = z.object({
  id: z.string(),
  destination: z.string(),
  status: z.string(),
  currentLocation: z.string(),
  day: z.number(),
  nextPlace: z.string(),
});

export const emergencyContactSchema = z.object({
  name: z.string(),
  number: z.string(),
});

export const emergencySchema = z.object({
  contacts: z.array(emergencyContactSchema),
  helpCenters: z.array(z.string()),
});

export const tripDataSchema = z.object({
  trip: tripInfoSchema,
  timeline: z.array(timelinePlaceSchema),
  emergency: emergencySchema,
});

export type TripData = z.infer<typeof tripDataSchema>;
export type TimelinePlace = z.infer<typeof timelinePlaceSchema>;
export type TransportOption = z.infer<typeof transportSchema>;
export type EmergencyInfo = z.infer<typeof emergencySchema>;
