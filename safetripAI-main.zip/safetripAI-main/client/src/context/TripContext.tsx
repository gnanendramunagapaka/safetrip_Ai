import React, { createContext, useContext, useState, ReactNode } from "react";
import { TimelinePlace } from "@shared/schema";

interface TripContextType {
  isTransportModalOpen: boolean;
  setTransportModalOpen: (open: boolean) => void;
  isMapModalOpen: boolean;
  setMapModalOpen: (open: boolean) => void;
  isEmergencyModalOpen: boolean;
  setEmergencyModalOpen: (open: boolean) => void;
  selectedPlace: TimelinePlace | null;
  setSelectedPlace: (place: TimelinePlace | null) => void;
  openTransportForPlace: (place: TimelinePlace) => void;
  openMapForPlace: (place: TimelinePlace) => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export function TripProvider({ children }: { children: ReactNode }) {
  const [isTransportModalOpen, setTransportModalOpen] = useState(false);
  const [isMapModalOpen, setMapModalOpen] = useState(false);
  const [isEmergencyModalOpen, setEmergencyModalOpen] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<TimelinePlace | null>(null);

  const openTransportForPlace = (place: TimelinePlace) => {
    setSelectedPlace(place);
    setTransportModalOpen(true);
  };

  const openMapForPlace = (place: TimelinePlace) => {
    setSelectedPlace(place);
    setMapModalOpen(true);
  };

  return (
    <TripContext.Provider
      value={{
        isTransportModalOpen,
        setTransportModalOpen,
        isMapModalOpen,
        setMapModalOpen,
        isEmergencyModalOpen,
        setEmergencyModalOpen,
        selectedPlace,
        setSelectedPlace,
        openTransportForPlace,
        openMapForPlace,
      }}
    >
      {children}
    </TripContext.Provider>
  );
}

export function useTripContext() {
  const context = useContext(TripContext);
  if (context === undefined) {
    throw new Error("useTripContext must be used within a TripProvider");
  }
  return context;
}
