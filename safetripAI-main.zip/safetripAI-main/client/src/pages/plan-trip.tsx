import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Calendar, Wallet, Sparkles, Loader2, CheckCircle2 } from "lucide-react";
import { useUser } from "@/context/UserContext";
import { api } from "@/services/api";
import { useToast } from "@/hooks/use-toast";

export default function PlanTrip() {
  const [, setLocation] = useLocation();
  const { user } = useUser();
  const { toast } = useToast();

  const [isGenerating, setIsGenerating] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [budget, setBudget] = useState("moderate");

  const destinationRef = useRef<HTMLInputElement>(null);
  const startDateRef = useRef<HTMLInputElement>(null);
  const endDateRef = useRef<HTMLInputElement>(null);

  const [planSummary, setPlanSummary] = useState({
    destination: "Chennai, India",
    startDate: "",
    endDate: "",
    budget: "moderate",
  });

  const budgetLabels: Record<string, string> = {
    budget: "Budget-Friendly",
    moderate: "Moderate",
    luxury: "Luxury",
  };

  const budgetCost: Record<string, string> = {
    budget: "₹8k",
    moderate: "₹15k",
    luxury: "₹40k",
  };

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);

    const destination = destinationRef.current?.value || "Chennai, India";
    const startDate = startDateRef.current?.value || "";
    const endDate = endDateRef.current?.value || "";

    setPlanSummary({ destination, startDate, endDate, budget });

    setTimeout(() => {
      setIsGenerating(false);
      setShowPreview(true);
    }, 2000);
  };

  const handleConfirm = async () => {
    if (!user) return;

    try {
      const result = await api.createTrip({
        userId: user.id,
        destination: planSummary.destination,
        startDate: planSummary.startDate || new Date().toISOString(),
        endDate: planSummary.endDate || new Date(Date.now() + 3 * 86400000).toISOString(),
        budget: planSummary.budget,
      });

      if (result.id) {
        localStorage.setItem("activeTrip", JSON.stringify({ id: result.id, destination: planSummary.destination }));
      }

      toast({
        title: "Trip confirmed! 🗺️",
        description: `Your trip to ${planSummary.destination} is ready. Let's go!`,
      });

      setLocation("/trip");
    } catch {
      toast({
        title: "Could not save trip",
        description: "Proceeding with demo itinerary.",
        variant: "destructive",
      });
      setLocation("/trip");
    }
  };

  return (
    <div className="max-w-3xl mx-auto animate-fade-in-up">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-4 text-primary">
          <Sparkles className="h-8 w-8" />
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold text-foreground mb-3">
          Plan Your Next Adventure
        </h1>
        <p className="text-muted-foreground text-lg max-w-xl mx-auto">
          Tell us where you want to go, and our AI will craft the perfect, safe itinerary for you.
        </p>
      </div>

      {!showPreview ? (
        <Card className="rounded-2xl shadow-xl border-none">
          <CardContent className="p-6 md:p-8">
            <form onSubmit={handleGenerate} className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="destination" className="text-base font-semibold">Where do you want to go?</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5" />
                    <Input
                      id="destination"
                      ref={destinationRef}
                      placeholder="e.g. Chennai, India"
                      className="pl-10 h-12 text-base rounded-xl bg-muted/30 focus:bg-background transition-colors"
                      required
                      defaultValue="Chennai, India"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate" className="text-base font-semibold">Start Date</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5" />
                      <Input
                        id="startDate"
                        ref={startDateRef}
                        type="date"
                        className="pl-10 h-12 text-base rounded-xl bg-muted/30 focus:bg-background transition-colors"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="endDate" className="text-base font-semibold">End Date</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5" />
                      <Input
                        id="endDate"
                        ref={endDateRef}
                        type="date"
                        className="pl-10 h-12 text-base rounded-xl bg-muted/30 focus:bg-background transition-colors"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="budget" className="text-base font-semibold flex items-center gap-2">
                    <Wallet className="h-5 w-5 text-muted-foreground" />
                    What's your budget?
                  </Label>
                  <Select value={budget} onValueChange={setBudget}>
                    <SelectTrigger id="budget" className="h-12 text-base rounded-xl bg-muted/30">
                      <SelectValue placeholder="Select budget" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="budget">Budget-Friendly</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="luxury">Luxury</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full h-14 text-lg rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                    AI is crafting your plan...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-5 w-5" />
                    Generate Smart Plan
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Card className="rounded-2xl shadow-xl border-none overflow-hidden animate-fade-in-up">
          <div className="bg-success/10 p-6 text-center border-b border-success/20">
            <CheckCircle2 className="h-12 w-12 text-success mx-auto mb-2" />
            <h2 className="text-2xl font-bold text-success-foreground">Itinerary Generated!</h2>
            <p className="text-success/80 font-medium">
              Your trip to <span className="font-bold">{planSummary.destination}</span> is ready.
            </p>
          </div>

          <CardContent className="p-6 md:p-8 space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="p-4 bg-muted/40 rounded-xl">
                <p className="text-sm text-muted-foreground uppercase font-semibold">Destination</p>
                <p className="text-lg font-bold truncate">{planSummary.destination.split(",")[0]}</p>
              </div>
              <div className="p-4 bg-muted/40 rounded-xl">
                <p className="text-sm text-muted-foreground uppercase font-semibold">Est. Cost</p>
                <p className="text-2xl font-bold">{budgetCost[budget]}</p>
              </div>
              <div className="p-4 bg-muted/40 rounded-xl">
                <p className="text-sm text-muted-foreground uppercase font-semibold">Safety Score</p>
                <p className="text-2xl font-bold text-success">High</p>
              </div>
              <div className="p-4 bg-muted/40 rounded-xl">
                <p className="text-sm text-muted-foreground uppercase font-semibold">Budget</p>
                <p className="text-lg font-bold">{budgetLabels[budget]}</p>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-bold text-lg">Highlights</h3>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-muted-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary shrink-0" /> Marina Beach Sunrise Walk
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary shrink-0" /> Kapaleeshwarar Temple Visit
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary shrink-0" /> Authentic Chettinad Cuisine Tour
                </li>
                <li className="flex items-center gap-2 text-muted-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary shrink-0" /> Pre-mapped Emergency Help Centers
                </li>
              </ul>
            </div>

            <Button
              onClick={handleConfirm}
              size="lg"
              className="w-full h-14 text-lg rounded-xl bg-success hover:bg-success/90 text-white shadow-lg shadow-success/20"
            >
              Confirm &amp; Open Workspace
            </Button>
            <Button variant="ghost" onClick={() => setShowPreview(false)} className="w-full">
              Make Changes
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
