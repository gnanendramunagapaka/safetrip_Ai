import { useState } from "react";
import { useTrip } from "@/hooks/use-trip";
import { useTripContext } from "@/context/TripContext";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Clock, ShieldAlert, Bus, AlertTriangle, ExternalLink } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function MyTrip() {
  const { data, isLoading, error } = useTrip();
  const { openTransportForPlace, openMapForPlace, setEmergencyModalOpen } = useTripContext();
  const [showFullMap, setShowFullMap] = useState(false);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-40 w-full rounded-2xl" />
        <div className="space-y-4 ml-6">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="text-center p-12 bg-muted/20 rounded-2xl border-dashed border-2">
        <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-bold">Failed to load trip workspace</h2>
        <p className="text-muted-foreground mt-2">Please try again later or check your connection.</p>
      </div>
    );
  }

  const { trip, timeline } = data;

  // Build a multi-destination Maps URL for all timeline places
  const allPlacesQuery = timeline
    .map((p) => encodeURIComponent(`${p.name}, ${p.location}, Chennai`))
    .join("/");
  const fullMapUrl = `https://www.google.com/maps/dir/${allPlacesQuery}`;

  const embedQuery = encodeURIComponent(`${trip.destination}, India`);
  const fullEmbedUrl = `https://www.google.com/maps?q=${embedQuery}&output=embed`;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in-up pb-24">

      {/* Trip Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground p-6 md:p-8 shadow-2xl shadow-primary/20">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Navigation className="w-64 h-64 -mt-10 -mr-10 rotate-12" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row justify-between gap-6 md:items-center">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-none font-bold">
                Day {trip.day}
              </Badge>
              <Badge variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-none font-bold">
                {trip.status}
              </Badge>
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-2">
              {trip.destination} Trip
            </h1>
            <p className="text-primary-foreground/80 font-medium flex items-center gap-2 text-lg">
              <MapPin className="h-5 w-5" /> Current: {trip.currentLocation}
            </p>
          </div>

          <Button
            variant="destructive"
            size="lg"
            className="rounded-xl shadow-lg bg-red-500 hover:bg-red-600 text-white font-bold h-14 px-6 self-start md:self-auto"
            onClick={() => setEmergencyModalOpen(true)}
          >
            <ShieldAlert className="h-5 w-5 mr-2" />
            SOS / Help
          </Button>
        </div>
      </div>

      {/* Timeline Section */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-foreground">Today's Itinerary</h2>
          <Button
            variant="outline"
            className="rounded-xl border-primary/20 text-primary hover:bg-primary/5"
            onClick={() => setShowFullMap(true)}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            View Full Map
          </Button>
        </div>

        <div className="relative ml-2 md:ml-4">
          {/* Vertical Line */}
          <div className="absolute left-4 top-4 bottom-10 w-0.5 bg-border" />

          <div className="space-y-6">
            {timeline.map((place, idx) => (
              <div key={place.id} className="relative flex gap-4 md:gap-6 animate-fade-in-up" style={{ animationDelay: `${idx * 100}ms` }}>

                {/* Timeline Dot */}
                <div className="relative z-10 flex flex-col items-center mt-6">
                  <div className="w-8 h-8 rounded-full bg-background border-4 border-primary flex items-center justify-center shadow-md">
                    <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                  </div>
                </div>

                {/* Place Card */}
                <Card className="flex-1 rounded-2xl shadow-sm border-border hover:shadow-md transition-shadow overflow-hidden group">
                  <div className="p-5 md:p-6">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <Badge variant="outline" className="text-xs font-semibold bg-muted/50">
                            <Clock className="w-3 h-3 mr-1" /> {place.time}
                          </Badge>
                          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{place.type}</span>
                        </div>
                        <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">{place.name}</h3>
                        <p className="text-sm text-muted-foreground flex items-center mt-1">
                          <MapPin className="h-3.5 w-3.5 mr-1" /> {place.distance} away
                        </p>
                      </div>

                      {/* Safety Quick Preview */}
                      <div className="bg-success/5 border border-success/20 rounded-xl p-3 text-right shrink-0">
                        <p className="text-xs font-semibold text-success uppercase mb-1">Safety Checked</p>
                        <p className="text-xs text-muted-foreground"><span className="font-medium text-foreground">{place.safety.hospital}</span> nearby</p>
                      </div>
                    </div>

                    <div className="h-px w-full bg-border/50 my-4" />

                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button
                        onClick={() => openTransportForPlace(place)}
                        className="flex-1 rounded-xl shadow-sm hover:-translate-y-0.5 transition-transform"
                      >
                        <Bus className="h-4 w-4 mr-2" />
                        Get Transport
                      </Button>

                      <Button
                        variant="secondary"
                        onClick={() => openMapForPlace(place)}
                        className="flex-1 rounded-xl hover:-translate-y-0.5 transition-transform"
                      >
                        <Navigation className="h-4 w-4 mr-2" />
                        View Route
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Full Map Dialog */}
      <Dialog open={showFullMap} onOpenChange={setShowFullMap}>
        <DialogContent className="sm:max-w-4xl h-[85vh] flex flex-col p-0 overflow-hidden">
          <DialogHeader className="p-5 border-b shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Full Itinerary Map — {trip.destination}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 relative overflow-hidden">
            <iframe
              title="Full trip map"
              src={fullEmbedUrl}
              width="100%"
              height="100%"
              style={{ border: 0, display: "block" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <div className="p-4 border-t bg-background flex justify-between items-center shrink-0">
            <Button variant="outline" className="rounded-xl" onClick={() => window.open(fullMapUrl, "_blank")}>
              <ExternalLink className="h-4 w-4 mr-2" />
              Open Route in Google Maps
            </Button>
            <Button className="rounded-xl" onClick={() => setShowFullMap(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
