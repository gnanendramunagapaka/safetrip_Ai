import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useTrip } from "@/hooks/use-trip";
import { useUser } from "@/context/UserContext";
import { Navigation, MapPin, Compass, ArrowRight, Activity, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data, isLoading, error } = useTrip();
  const { user } = useUser();

  const firstName = user?.name?.split(" ")[0] || "Traveler";

  return (
    <div className="space-y-8 animate-fade-in-up">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground">Welcome back, {firstName}! 👋</h1>
          <p className="text-muted-foreground mt-2 text-lg">Here's an overview of your current adventure.</p>
        </div>
        <Button asChild size="lg" className="rounded-xl shadow-lg shadow-primary/20 group">
          <Link href="/plan">
            <Compass className="mr-2 h-5 w-5" />
            Plan New Trip
          </Link>
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-48 rounded-2xl col-span-2" />
          <Skeleton className="h-48 rounded-2xl" />
        </div>
      ) : error || !data ? (
        <Card className="border-dashed bg-muted/30">
          <CardContent className="flex flex-col items-center justify-center h-64 text-center">
            <Navigation className="h-12 w-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-xl font-semibold">No active trip found</h3>
            <p className="text-muted-foreground mt-2 mb-6">You don't have any ongoing trips right now.</p>
            <Button asChild>
              <Link href="/plan">Start Planning</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Active Trip Card */}
          <Card className="lg:col-span-2 border-none shadow-xl bg-gradient-to-br from-primary/5 via-white to-background relative overflow-hidden rounded-2xl">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Navigation className="w-48 h-48" />
            </div>

            <CardHeader className="pb-2 relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-3 py-1 bg-success/10 text-success text-xs font-bold uppercase tracking-wider rounded-full flex items-center gap-1.5">
                  <Activity className="w-3 h-3" /> Active Trip
                </span>
                <span className="px-3 py-1 bg-muted text-muted-foreground text-xs font-bold uppercase tracking-wider rounded-full">
                  Day {data.trip.day}
                </span>
              </div>
              <CardTitle className="text-3xl font-extrabold">{data.trip.destination} Trip</CardTitle>
              <CardDescription className="text-base font-medium">Status: {data.trip.status}</CardDescription>
            </CardHeader>

            <CardContent className="relative z-10 pt-4">
              <div className="flex flex-col sm:flex-row gap-6 sm:gap-12 p-6 bg-white rounded-xl shadow-sm border border-border/50">
                <div>
                  <p className="text-sm font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1">
                    <MapPin className="h-4 w-4" /> Current Location
                  </p>
                  <p className="text-lg font-bold">{data.trip.currentLocation}</p>
                </div>

                <div className="hidden sm:flex items-center text-muted-foreground/30">
                  <ArrowRight className="h-8 w-8" />
                </div>

                <div>
                  <p className="text-sm font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1">
                    <Navigation className="h-4 w-4" /> Next Destination
                  </p>
                  <p className="text-lg font-bold">{data.trip.nextPlace}</p>
                </div>
              </div>

              <div className="mt-6">
                <Button asChild size="lg" className="w-full sm:w-auto rounded-xl shadow-md">
                  <Link href="/trip">Open My Trip Workspace</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Up Next Card */}
          <Card className="rounded-2xl border border-border shadow-md">
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                Up Next Today
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {data.timeline.slice(0, 3).map((place, idx) => (
                <div key={place.id} className="flex gap-4 relative">
                  {idx !== 2 && (
                    <div className="absolute left-1.5 top-6 bottom-[-16px] w-[2px] bg-border z-0" />
                  )}
                  <div className="w-3 h-3 rounded-full bg-primary mt-1.5 relative z-10 ring-4 ring-background" />
                  <div>
                    <p className="text-sm font-bold text-foreground">{place.time}</p>
                    <p className="text-base font-semibold">{place.name}</p>
                    <p className="text-sm text-muted-foreground">{place.type}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
