import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Settings, Phone, Map, ShieldCheck, History, LogOut } from "lucide-react";
import { useTrip } from "@/hooks/use-trip";
import { useUser } from "@/context/UserContext";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { data } = useTrip();
  const { user, logout } = useUser();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const initials = user?.name
    ? user.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)
    : "?";

  const handleCall = (number: string, name: string) => {
    toast({ title: `Calling ${name}...`, description: `Dialing ${number}` });
    window.location.href = `tel:${number}`;
  };

  const handleLogout = () => {
    logout();
    setLocation("/auth");
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Profile Settings</h1>
        <Button variant="outline" className="rounded-xl text-destructive hover:bg-destructive/10 hover:text-destructive border-destructive/30" onClick={handleLogout}>
          <LogOut className="w-4 h-4 mr-2" /> Logout
        </Button>
      </div>

      {/* Profile Header Card */}
      <Card className="rounded-2xl border-none shadow-lg overflow-hidden relative">
        <div className="h-32 bg-gradient-to-r from-primary/80 to-accent" />
        <CardContent className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end gap-6 -mt-12 sm:-mt-16">
            <Avatar className="h-24 w-24 sm:h-32 sm:w-32 border-4 border-background shadow-xl">
              <AvatarFallback className="text-3xl bg-primary text-primary-foreground font-bold">
                {initials}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1 pb-2">
              <h2 className="text-2xl font-bold">{user?.name || "Traveler"}</h2>
              <p className="text-muted-foreground text-sm mt-1">{user?.email}</p>
              <p className="text-muted-foreground flex items-center gap-1 mt-1">
                <Map className="h-4 w-4" /> Explorer Level
              </p>
            </div>

            <Button variant="outline" className="rounded-xl shrink-0" onClick={() => toast({ title: "Edit Profile coming soon!" })}>
              <Settings className="w-4 h-4 mr-2" /> Edit Profile
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Emergency Contacts */}
        <Card className="rounded-2xl shadow-md border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-success" />
              Emergency Contacts
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data?.emergency.contacts.map((contact, i) => (
              <div key={i} className="flex justify-between items-center py-3 border-b last:border-0 last:pb-0">
                <div>
                  <p className="font-semibold">{contact.name}</p>
                  <p className="text-sm text-muted-foreground font-mono">{contact.number}</p>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-9 w-9 rounded-full hover:bg-primary/10 hover:text-primary"
                  onClick={() => handleCall(contact.number, contact.name)}
                >
                  <Phone className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <Button
              variant="outline"
              className="w-full mt-4 rounded-xl border-dashed"
              onClick={() => toast({ title: "Add Contact coming soon!" })}
            >
              + Add Contact
            </Button>
          </CardContent>
        </Card>

        {/* Trip History */}
        <Card className="rounded-2xl shadow-md border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <History className="w-5 h-5 text-primary" />
              Trip History
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-primary/5 rounded-xl border border-primary/20 flex justify-between items-center">
              <div>
                <p className="font-bold text-primary">{data?.trip.destination || "Chennai"} Trip</p>
                <p className="text-xs text-primary/70 font-medium">Active Now · Day {data?.trip.day}</p>
              </div>
              <Button size="sm" className="rounded-lg" asChild>
                <a href="/trip">Continue</a>
              </Button>
            </div>
            <div className="p-4 bg-muted/40 rounded-xl flex justify-between items-center">
              <div>
                <p className="font-bold">Goa Weekend</p>
                <p className="text-xs text-muted-foreground">Completed · Oct 2023</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => toast({ title: "Trip details coming soon!" })}>
                View
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
