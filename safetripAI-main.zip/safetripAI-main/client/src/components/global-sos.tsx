import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import { useTripContext } from "@/context/TripContext";

export function GlobalSOSButton() {
  const { setEmergencyModalOpen } = useTripContext();

  return (
    <Button
      variant="destructive"
      size="icon"
      onClick={() => setEmergencyModalOpen(true)}
      className="fixed bottom-6 right-6 h-16 w-16 rounded-full shadow-2xl pulse-ring z-50 hover:scale-105 active:scale-95 transition-all duration-300"
      aria-label="Emergency SOS"
    >
      <AlertTriangle className="h-7 w-7" />
    </Button>
  );
}
