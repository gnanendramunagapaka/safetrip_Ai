import { ReactNode } from "react";
import { useLocation } from "wouter";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./app-sidebar";
import { GlobalSOSButton } from "./global-sos";
import { TransportModal } from "./modals/transport-modal";
import { MapModal } from "./modals/map-modal";
import { EmergencyModal } from "./modals/emergency-modal";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { MapPin, LogOut } from "lucide-react";
import { useTrip } from "@/hooks/use-trip";
import { useUser } from "@/context/UserContext";

export function Layout({ children }: { children: ReactNode }) {
  const { data } = useTrip();
  const { user, logout } = useUser();
  const [, setLocation] = useLocation();

  const initials = user?.name
    ? user.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)
    : "?";

  const style = {
    "--sidebar-width": "18rem",
  } as React.CSSProperties;

  const handleLogout = () => {
    logout();
    setLocation("/auth");
  };

  return (
    <SidebarProvider style={style}>
      <div className="flex h-screen w-full bg-background overflow-hidden">
        <AppSidebar />

        <div className="flex flex-col flex-1 min-w-0">
          <header className="h-16 px-6 border-b border-border/40 bg-white/50 backdrop-blur-sm flex items-center justify-between z-10 sticky top-0">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="text-muted-foreground hover:text-foreground" />

              {data && (
                <div className="hidden sm:flex items-center gap-2 text-sm px-3 py-1.5 bg-muted/50 rounded-full border border-border/50">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="text-muted-foreground">Current:</span>
                  <span className="font-semibold text-foreground">{data.trip.currentLocation}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3">
              {user && (
                <span className="hidden sm:block text-sm font-medium text-muted-foreground">
                  {user.name}
                </span>
              )}
              <Avatar className="h-9 w-9 border-2 border-primary/20 shadow-sm">
                <AvatarFallback className="bg-primary/10 text-primary font-bold text-sm">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 text-muted-foreground hover:text-destructive"
                onClick={handleLogout}
                title="Logout"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </header>

          <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 scroll-smooth">
            <div className="max-w-6xl mx-auto">
              {children}
            </div>
          </main>
        </div>

        <GlobalSOSButton />
        <TransportModal />
        <MapModal />
        <EmergencyModal />
      </div>
    </SidebarProvider>
  );
}
