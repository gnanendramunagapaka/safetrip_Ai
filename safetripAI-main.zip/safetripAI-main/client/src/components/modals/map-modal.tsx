import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTripContext } from "@/context/TripContext";
import { MapPin, Navigation, ExternalLink } from "lucide-react";

export function MapModal() {
  const { isMapModalOpen, setMapModalOpen, selectedPlace } = useTripContext();

  if (!selectedPlace) return null;

  const query = encodeURIComponent(`${selectedPlace.name}, ${selectedPlace.location}, Chennai, India`);
  const embedUrl = `https://www.google.com/maps?q=${query}&output=embed`;
  const openUrl = `https://www.google.com/maps/search/?api=1&query=${query}`;
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${query}`;

  return (
    <Dialog open={isMapModalOpen} onOpenChange={setMapModalOpen}>
      <DialogContent className="sm:max-w-3xl h-[85vh] flex flex-col p-0 overflow-hidden bg-card">
        <DialogHeader className="p-5 pb-4 border-b shrink-0">
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Route to {selectedPlace.name}
          </DialogTitle>
          <DialogDescription>
            {selectedPlace.location} • {selectedPlace.distance} away
          </DialogDescription>
        </DialogHeader>

        {/* Google Maps Embed */}
        <div className="flex-1 relative overflow-hidden">
          <iframe
            title={`Map to ${selectedPlace.name}`}
            src={embedUrl}
            width="100%"
            height="100%"
            style={{ border: 0, display: "block" }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>

        <div className="p-4 bg-background border-t flex flex-col sm:flex-row gap-3 shrink-0">
          <Button
            className="flex-1 rounded-xl"
            onClick={() => window.open(directionsUrl, "_blank")}
          >
            <Navigation className="h-4 w-4 mr-2" />
            Get Directions
          </Button>
          <Button
            variant="outline"
            className="flex-1 rounded-xl"
            onClick={() => window.open(openUrl, "_blank")}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Open in Google Maps
          </Button>
          <Button variant="ghost" className="sm:w-auto rounded-xl" onClick={() => setMapModalOpen(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
