import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Car, Train, Bus, Bike, Info, CheckCircle2 } from "lucide-react";
import { useTripContext } from "@/context/TripContext";
import { TransportOption } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export function TransportModal() {
  const { isTransportModalOpen, setTransportModalOpen, selectedPlace } = useTripContext();
  const { toast } = useToast();
  const [selectedType, setSelectedType] = useState<string | null>(null);

  if (!selectedPlace) return null;

  const getTransportIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "cab":
      case "uber":
      case "ola": return <Car className="h-5 w-5" />;
      case "metro": return <Train className="h-5 w-5" />;
      case "bus": return <Bus className="h-5 w-5" />;
      case "rapido": return <Bike className="h-5 w-5" />;
      default: return <Info className="h-5 w-5" />;
    }
  };

  const handleSelect = (option: TransportOption) => {
    setSelectedType(option.type);
    toast({
      title: `${option.type} booked! 🎉`,
      description: `Heading to ${selectedPlace.name} — ETA ${option.time}. Estimated cost ₹${option.price}.`,
      duration: 4000,
    });
    setTimeout(() => {
      setTransportModalOpen(false);
      setSelectedType(null);
    }, 1200);
  };

  return (
    <Dialog open={isTransportModalOpen} onOpenChange={(open) => { setTransportModalOpen(open); if (!open) setSelectedType(null); }}>
      <DialogContent className="sm:max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Transport to {selectedPlace.name}</DialogTitle>
          <DialogDescription>
            Choose the best way to get to your next destination.
          </DialogDescription>
        </DialogHeader>

        <div className="mt-4 space-y-3">
          {selectedPlace.transport.map((option: TransportOption, idx) => {
            const isSelected = selectedType === option.type;
            return (
              <div
                key={idx}
                className={`p-4 rounded-xl border transition-all duration-200 flex items-center justify-between hover:shadow-md ${isSelected
                    ? "border-success bg-success/5"
                    : option.recommended
                      ? "border-primary/50 bg-primary/5"
                      : "border-border bg-background"
                  }`}
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-full ${isSelected ? "bg-success text-white" : option.recommended ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                    {isSelected ? <CheckCircle2 className="h-5 w-5" /> : getTransportIcon(option.type)}
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground capitalize flex items-center gap-2">
                      {option.type}
                      {option.recommended && !isSelected && (
                        <Badge variant="default" className="text-[10px] uppercase bg-primary hover:bg-primary">
                          Recommended
                        </Badge>
                      )}
                      {isSelected && (
                        <Badge className="text-[10px] uppercase bg-success hover:bg-success">
                          Selected
                        </Badge>
                      )}
                    </h4>
                    <p className="text-sm text-muted-foreground mt-0.5">Est. {option.time}</p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-lg">₹{option.price}</div>
                  <Button
                    size="sm"
                    variant={isSelected ? "secondary" : option.recommended ? "default" : "outline"}
                    className="mt-2 w-full rounded-lg"
                    onClick={() => handleSelect(option)}
                    disabled={isSelected}
                  >
                    {isSelected ? "Booked!" : "Select"}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
