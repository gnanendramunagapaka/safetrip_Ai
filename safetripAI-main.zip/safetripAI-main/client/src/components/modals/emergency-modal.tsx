import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Phone, ShieldAlert, FileWarning, CheckCircle2, ExternalLink } from "lucide-react";
import { useTripContext } from "@/context/TripContext";
import { useTrip } from "@/hooks/use-trip";
import { useToast } from "@/hooks/use-toast";

export function EmergencyModal() {
  const { isEmergencyModalOpen, setEmergencyModalOpen } = useTripContext();
  const { data: tripData } = useTrip();
  const { toast } = useToast();
  const [sosSent, setSosSent] = useState(false);

  const emergency = tripData?.emergency;

  const handleSOS = () => {
    setSosSent(true);
    // Save SOS log to localStorage
    const sosLog = {
      timestamp: new Date().toISOString(),
      location: tripData?.trip.currentLocation || "Unknown",
      destination: tripData?.trip.destination || "Unknown",
    };
    const existing = JSON.parse(localStorage.getItem("sos_logs") || "[]");
    existing.push(sosLog);
    localStorage.setItem("sos_logs", JSON.stringify(existing));

    toast({
      title: "🚨 SOS Alert Sent!",
      description: `Emergency services notified at ${sosLog.location}. Help is on the way.`,
      duration: 6000,
    });
  };

  const handleCall = (number: string, name: string) => {
    toast({
      title: `Calling ${name}...`,
      description: `Dialing ${number}`,
      duration: 3000,
    });
    window.location.href = `tel:${number}`;
  };

  const handleNavigateToCenter = (center: string) => {
    const query = encodeURIComponent(`${center}, Chennai`);
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${query}`, "_blank");
  };

  const handleClose = () => {
    setEmergencyModalOpen(false);
    setSosSent(false);
  };

  return (
    <Dialog open={isEmergencyModalOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-card border-destructive/20 shadow-2xl shadow-destructive/10">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-destructive flex items-center gap-2">
            <AlertTriangle className="h-6 w-6" />
            Emergency Assistance
          </DialogTitle>
          <DialogDescription className="text-base">
            Get immediate help for your current location.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-2">
          {/* SOS Button */}
          <Button
            variant={sosSent ? "secondary" : "destructive"}
            size="lg"
            className={`w-full h-16 text-lg font-bold shadow-lg rounded-xl relative overflow-hidden group transition-all ${sosSent ? "bg-success/10 text-success border-success/30 hover:bg-success/20" : "shadow-destructive/30"
              }`}
            onClick={handleSOS}
            disabled={sosSent}
          >
            {sosSent ? (
              <>
                <CheckCircle2 className="h-6 w-6 mr-2" />
                SOS Alert Sent!
              </>
            ) : (
              <>
                <div className="absolute inset-0 bg-white/20 translate-y-[100%] group-hover:translate-y-0 transition-transform duration-300" />
                <ShieldAlert className="h-6 w-6 mr-2" />
                SEND SOS ALERT
              </>
            )}
          </Button>

          {emergency && (
            <>
              {/* Nearby Help Centers */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold uppercase text-muted-foreground tracking-wider">Nearby Help Centers</h4>
                <div className="grid grid-cols-1 gap-2">
                  {emergency.helpCenters.map((center, idx) => (
                    <div key={idx} className="bg-background border rounded-lg p-3 flex justify-between items-center hover:border-primary/40 transition-colors">
                      <span className="font-medium text-sm">{center}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 gap-1.5"
                        onClick={() => handleNavigateToCenter(center)}
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        Navigate
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Emergency Contacts */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold uppercase text-muted-foreground tracking-wider">Emergency Contacts</h4>
                <div className="grid grid-cols-1 gap-2">
                  {emergency.contacts.map((contact, idx) => (
                    <div
                      key={idx}
                      className="bg-background border rounded-lg p-3 flex justify-between items-center group hover:border-primary transition-colors cursor-pointer"
                      onClick={() => handleCall(contact.number, contact.name)}
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold text-sm">{contact.name}</span>
                        <span className="text-xs text-muted-foreground font-mono">{contact.number}</span>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-9 w-9 rounded-full group-hover:bg-primary/10 group-hover:text-primary"
                        onClick={(e) => { e.stopPropagation(); handleCall(contact.number, contact.name); }}
                      >
                        <Phone className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          <div className="pt-2">
            <Button
              variant="secondary"
              className="w-full rounded-xl"
              onClick={() => {
                handleClose();
                toast({
                  title: "Report submitted",
                  description: "Our support team will get back to you shortly.",
                });
              }}
            >
              <FileWarning className="h-4 w-4 mr-2" />
              Report Lost Item / Issue
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
