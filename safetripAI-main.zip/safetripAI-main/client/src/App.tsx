import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";
import { TripProvider } from "@/context/TripContext";
import { UserProvider, useUser } from "@/context/UserContext";

// Pages
import Dashboard from "@/pages/dashboard";
import PlanTrip from "@/pages/plan-trip";
import MyTrip from "@/pages/my-trip";
import Profile from "@/pages/profile";
import Auth from "@/pages/auth";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user } = useUser();
  if (!user) return <Redirect to="/auth" />;
  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function Router() {
  const { user } = useUser();

  return (
    <Switch>
      <Route path="/auth">
        {user ? <Redirect to="/dashboard" /> : <Auth />}
      </Route>
      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/dashboard" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/plan" component={() => <ProtectedRoute component={PlanTrip} />} />
      <Route path="/trip" component={() => <ProtectedRoute component={MyTrip} />} />
      <Route path="/profile" component={() => <ProtectedRoute component={Profile} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <UserProvider>
          <TripProvider>
            <Toaster />
            <Router />
          </TripProvider>
        </UserProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
