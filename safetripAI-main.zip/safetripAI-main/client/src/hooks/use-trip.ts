import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useTrip() {
  return useQuery({
    queryKey: [api.trip.get.path],
    queryFn: async () => {
      const res = await fetch(api.trip.get.path, { credentials: "include" });
      if (!res.ok) {
        if (res.status === 404) {
          throw new Error("Trip not found");
        }
        throw new Error("Failed to fetch trip data");
      }
      return api.trip.get.responses[200].parse(await res.json());
    },
    // Adding some retry logic makes UI feel more resilient
    retry: 1,
  });
}
