const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";

export const api = {
  // Auth
  register: async (name: string, email: string, password: string) => {
    const res = await fetch(`${API_BASE}/api/users/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    return res.json();
  },

  login: async (email: string, password: string) => {
    const res = await fetch(`${API_BASE}/api/users/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    return res.json();
  },

  getUser: async (userId: number) => {
    const res = await fetch(`${API_BASE}/api/users/${userId}`);
    return res.json();
  },

  // Trips
  createTrip: async (tripData: any) => {
    const res = await fetch(`${API_BASE}/api/trips/create`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tripData),
    });
    return res.json();
  },

  getUserTrips: async (userId: number) => {
    const res = await fetch(`${API_BASE}/api/trips/${userId}`);
    return res.json();
  },

  getTripDetails: async (tripId: number) => {
    const res = await fetch(`${API_BASE}/api/trips/details/${tripId}`);
    return res.json();
  },

  // Transport
  getTransportOptions: async () => {
    const res = await fetch(`${API_BASE}/api/transport/options`);
    return res.json();
  },

  selectTransport: async (placeId: number, transportType: string, price: number) => {
    const res = await fetch(`${API_BASE}/api/transport/select`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ placeId, transportType, price }),
    });
    return res.json();
  },

  // Emergency
  getNearbyHelpCenters: async (lat: number, lng: number) => {
    const res = await fetch(`${API_BASE}/api/emergency/nearby?lat=${lat}&lng=${lng}`);
    return res.json();
  },

  // Legacy
  getTrip: async () => {
    const res = await fetch(`${API_BASE}/api/trip`);
    return res.json();
  },
};
