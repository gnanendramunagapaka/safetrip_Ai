## Packages
(none needed)

## Notes
- Expecting a standard layout with Shadcn UI components.
- The app uses custom React Context (`TripContext`) to manage global modal states (Transport, Map, Emergency) smoothly over the workspace.
- The `api.trip.get` endpoint provides standard mock data. The UI implements full loading, error, and empty states.
