import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import * as authController from "./controllers/auth";
import * as tripController from "./controllers/trip";
import * as transportController from "./controllers/transport";
import * as emergencyController from "./controllers/emergency";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Auth routes
  app.post("/api/users/register", authController.register);
  app.post("/api/users/login", authController.login);
  app.get("/api/users/:id", authController.getUser);

  // Trip routes
  app.post("/api/trips/create", tripController.createTrip);
  app.get("/api/trips/:userId", tripController.getUserTrips);
  app.get("/api/trips/details/:tripId", tripController.getTripDetails);

  // Transport routes
  app.get("/api/transport/options", transportController.getTransportOptions);
  app.post("/api/transport/select", transportController.selectTransport);

  // Emergency routes
  app.get("/api/emergency/nearby", emergencyController.getNearbyHelpCenters);

  // Legacy route for existing frontend
  app.get(api.trip.get.path, async (req, res) => {
    try {
      const tripData = await storage.getTripData();
      res.json(tripData);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}