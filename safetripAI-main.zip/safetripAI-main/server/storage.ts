import { type TripData } from "@shared/schema";

export interface IStorage {
  getTripData(): Promise<TripData>;
}

export class MemStorage implements IStorage {
  private tripData: TripData;

  constructor() {
    this.tripData = {
      trip: {
        id: "trip_001",
        destination: "Chennai",
        status: "ACTIVE",
        currentLocation: "The Residency Towers, T Nagar",
        day: 2,
        nextPlace: "Marina Beach"
      },
      timeline: [
        {
          id: "place_1",
          time: "08:00 AM",
          name: "Saravana Bhavan Breakfast",
          type: "restaurant",
          distance: "1.2 km",
          location: "T Nagar",
          transport: [
            { type: "Rapido", price: 60, time: "5 min", recommended: true },
            { type: "Uber", price: 90, time: "7 min" },
            { type: "Bus", price: 10, time: "15 min" }
          ],
          safety: {
            hospital: "Apollo Hospital – 900m",
            police: "T Nagar Police Station – 700m"
          }
        },
        {
          id: "place_2",
          time: "10:30 AM",
          name: "Marina Beach",
          type: "attraction",
          distance: "6 km",
          location: "Marina Beach Road",
          transport: [
            { type: "Rapido", price: 120, time: "15 min", recommended: true },
            { type: "Uber", price: 180, time: "18 min" },
            { type: "Bus", price: 20, time: "30 min" }
          ],
          safety: {
            hospital: "Rajiv Gandhi Hospital – 1.5 km",
            police: "Marina Police Station – 500m"
          }
        },
        {
          id: "place_3",
          time: "01:30 PM",
          name: "Murugan Idli Shop Lunch",
          type: "restaurant",
          distance: "4 km",
          location: "Besant Nagar",
          transport: [
            { type: "Rapido", price: 100, time: "12 min", recommended: true },
            { type: "Uber", price: 150, time: "15 min" },
            { type: "Bus", price: 15, time: "25 min" }
          ],
          safety: {
            hospital: "Fortis Hospital – 2 km",
            police: "Besant Nagar Police Station – 1 km"
          }
        },
        {
          id: "place_4",
          time: "04:00 PM",
          name: "Kapaleeshwarar Temple",
          type: "attraction",
          distance: "3 km",
          location: "Mylapore",
          transport: [
            { type: "Rapido", price: 80, time: "10 min", recommended: true },
            { type: "Uber", price: 120, time: "12 min" },
            { type: "Bus", price: 10, time: "20 min" }
          ],
          safety: {
            hospital: "Vijaya Hospital – 1 km",
            police: "Mylapore Police Station – 600m"
          }
        },
        {
          id: "place_5",
          time: "07:30 PM",
          name: "Dinner at Anjappar Chettinad",
          type: "restaurant",
          distance: "5 km",
          location: "Anna Nagar",
          transport: [
            { type: "Rapido", price: 110, time: "13 min", recommended: true },
            { type: "Uber", price: 160, time: "16 min" },
            { type: "Bus", price: 20, time: "28 min" }
          ],
          safety: {
            hospital: "Sri Ramachandra Hospital – 2.5 km",
            police: "Anna Nagar Police Station – 1.2 km"
          }
        }
      ],
      emergency: {
        contacts: [
          { name: "Police", number: "100" },
          { name: "Ambulance", number: "108" },
          { name: "Fire", number: "101" },
          { name: "Tourist Helpline", number: "1800-111-363" }
        ],
        helpCenters: [
          "Apollo Hospital Chennai",
          "Marina Police Station",
          "Tourist Help Center Chennai",
          "Rajiv Gandhi Government General Hospital"
        ]
      }
    };
  }

  async getTripData(): Promise<TripData> {
    return this.tripData;
  }
}

export const storage = new MemStorage();