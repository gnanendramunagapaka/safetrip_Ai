// Database removed — app uses in-memory storage with mock data.
// No external database connection required.
export { };
