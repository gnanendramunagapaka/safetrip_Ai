import { Request, Response } from "express";

export async function getNearbyHelpCenters(req: Request, res: Response) {
  try {
    const { lat, lng } = req.query;
    
    if (!lat || !lng) {
      return res.status(400).json({ message: "Latitude and longitude required" });
    }

    const mockHelpCenters = {
      hospitals: [
        { name: "Apollo Hospital", distance: "900m", phone: "+91-44-2829-3333" },
        { name: "Fortis Malar Hospital", distance: "1.5km", phone: "+91-44-4289-2222" },
        { name: "MIOT Hospital", distance: "2.3km", phone: "+91-44-4200-2288" },
      ],
      police: [
        { name: "T Nagar Police Station", distance: "700m", phone: "100" },
        { name: "Marina Police Station", distance: "1.2km", phone: "100" },
      ],
    };

    res.json(mockHelpCenters);
  } catch (err: any) {
    res.status(500).json({ message: "Failed to fetch help centers" });
  }
}
