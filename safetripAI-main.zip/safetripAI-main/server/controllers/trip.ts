import { Request, Response } from "express";
import { storage } from "../storage";

interface Trip {
  id: number;
  userId: number;
  destination: string;
  startDate: string;
  endDate: string;
  budget?: string;
  status: string;
  currentDay: number;
}

// In-memory trip store
const trips: Trip[] = [];
let nextTripId = 1;

export async function createTrip(req: Request, res: Response) {
  try {
    const { userId, destination, startDate, endDate, budget } = req.body;

    if (!userId || !destination || !startDate || !endDate) {
      return res.status(400).json({ message: "userId, destination, startDate, and endDate are required" });
    }

    const trip: Trip = {
      id: nextTripId++,
      userId,
      destination,
      startDate,
      endDate,
      budget,
      status: "ACTIVE",
      currentDay: 1,
    };

    trips.push(trip);
    res.json({ id: trip.id, message: "Trip created successfully" });
  } catch (err: any) {
    res.status(500).json({ message: err.message || "Failed to create trip" });
  }
}

export async function getUserTrips(req: Request, res: Response) {
  try {
    const userId = parseInt(String(req.params.userId), 10);
    const userTrips = trips.filter((t) => t.userId === userId);
    res.json(userTrips);
  } catch (err: any) {
    res.status(500).json({ message: "Failed to fetch trips" });
  }
}

export async function getTripDetails(req: Request, res: Response) {
  try {
    const tripId = parseInt(String(req.params.tripId), 10);
    const trip = trips.find((t) => t.id === tripId);

    if (!trip) {
      // Return mock data for any unknown trip ID (useful for demo)
      const mockData = await storage.getTripData();
      return res.json(mockData);
    }

    // Return mock timeline enriched with the trip's destination info
    const mockData = await storage.getTripData();
    res.json({
      ...mockData,
      trip: {
        ...mockData.trip,
        id: `trip_${trip.id}`,
        destination: trip.destination,
        status: trip.status,
        day: trip.currentDay,
      },
    });
  } catch (err: any) {
    res.status(500).json({ message: "Failed to fetch trip details" });
  }
}
