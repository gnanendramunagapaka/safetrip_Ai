import { Request, Response } from "express";

export async function getTransportOptions(req: Request, res: Response) {
  const mockOptions = [
    { type: "Rapido", price: 80, time: "8 min", recommended: true },
    { type: "Uber", price: 120, time: "10 min", recommended: false },
    { type: "Bus", price: 15, time: "20 min", recommended: false },
    { type: "Rental Car", price: 500, time: "Available", recommended: false },
  ];
  
  res.json(mockOptions);
}

export async function selectTransport(req: Request, res: Response) {
  try {
    const { placeId, transportType, price } = req.body;
    res.json({ message: "Transport selected", placeId, transportType, price });
  } catch (err: any) {
    res.status(500).json({ message: "Failed to select transport" });
  }
}
