import { Request, Response } from "express";

interface User {
  id: number;
  name: string;
  email: string;
  password: string;
}

// In-memory user store — persists for server session lifetime
const users = new Map<string, User>();
let nextId = 1;

export async function register(req: Request, res: Response) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: "Name, email, and password are required" });
    }

    if (users.has(email)) {
      return res.status(400).json({ message: "Email already registered" });
    }

    const user: User = { id: nextId++, name, email, password };
    users.set(email, user);

    res.json({ id: user.id, name: user.name, email: user.email });
  } catch (err: any) {
    res.status(400).json({ message: err.message || "Registration failed" });
  }
}

export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const user = users.get(email);

    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    res.json({ id: user.id, name: user.name, email: user.email });
  } catch (err: any) {
    res.status(500).json({ message: "Login failed" });
  }
}

export async function getUser(req: Request, res: Response) {
  try {
    const userId = parseInt(req.params.id);
    const user = [...users.values()].find((u) => u.id === userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ id: user.id, name: user.name, email: user.email });
  } catch (err: any) {
    res.status(500).json({ message: "Failed to fetch user" });
  }
}
